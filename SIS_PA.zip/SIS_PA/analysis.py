import pandas as pd
import numpy as np
from scipy.stats import norm
import matplotlib.pyplot as plt
import os

STUDENT_ID = "23B151046"   # your ID
FILENAME = f"sis_dataset_23B151046.csv"

df = pd.read_csv(FILENAME, parse_dates=["install_date"])


# ========= 6. VISUALIZATIONS (CHARTS) =========
print("===== CREATING CHARTS =====")

# Folder to save figures
output_dir = "figures"
os.makedirs(output_dir, exist_ok=True)

# 1) DAU over time
dau_by_day = df.groupby("install_date")["user_id"].nunique()

plt.figure()
plt.plot(dau_by_day.index, dau_by_day.values)
plt.xlabel("Date")
plt.ylabel("DAU")
plt.title("Daily Active Users Over Time")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "dau_over_time.png"), dpi=150)
plt.close()

# 2) Session length distribution
plt.figure()
plt.hist(df["session_length"], bins=20)
plt.xlabel("Session length (minutes)")
plt.ylabel("Number of users")
plt.title("Session Length Distribution")
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "session_length_distribution.png"), dpi=150)
plt.close()

# 3) Funnel bar chart: Install → Tutorial → D7 → Purchase
installs = len(df)
tutorial_completed = (df["tutorial_complete"] == 1).sum()
retained_d7 = (df["retention_d7"] == 1).sum()
purchasers = (df["revenue"] > 0).sum()

steps = ["Install", "Tutorial Complete", "D7 Retained", "Purchase"]
values = [installs, tutorial_completed, retained_d7, purchasers]

plt.figure()
plt.bar(steps, values)
plt.xlabel("Funnel Step")
plt.ylabel("Number of users")
plt.title("Onboarding & Retention Funnel")
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "funnel_bar_chart.png"), dpi=150)
plt.close()

# 4) D7 retention by install week (cohort bar chart)
df["install_week"] = df["install_date"].dt.isocalendar().week
cohort_d7 = df.groupby("install_week")["retention_d7"].mean()

plt.figure()
plt.bar(cohort_d7.index.astype(str), cohort_d7.values)
plt.xlabel("Install Week")
plt.ylabel("D7 Retention")
plt.title("D7 Retention by Install Week")
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "d7_retention_by_week.png"), dpi=150)
plt.close()

# 5) Revenue distribution histogram
plt.figure()
plt.hist(df["revenue"], bins=20)
plt.xlabel("Revenue per user")
plt.ylabel("Number of users")
plt.title("Revenue Distribution")
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "revenue_distribution.png"), dpi=150)
plt.close()

# 6) Whales vs others (pie chart)
paying = df[df["revenue"] > 0].copy()
paying_sorted = paying.sort_values("revenue", ascending=False)
top_k = max(1, int(0.05 * len(paying))) if len(paying) > 0 else 0

if top_k > 0:
    whales = paying_sorted.head(top_k)
    whales_revenue = whales["revenue"].sum()
    total_revenue = df["revenue"].sum()
    others_revenue = total_revenue - whales_revenue

    plt.figure()
    plt.pie(
        [whales_revenue, others_revenue],
        labels=["Whales (top 5%)", "Other payers"],
        autopct="%1.1f%%"
    )
    plt.title("Revenue Share: Whales vs Other Payers")
    plt.savefig(os.path.join(output_dir, "whales_vs_others.png"), dpi=150)
    plt.close()

# 7) A/B test comparison (A vs B)
groupA = df[df["group"] == "A"]
groupB = df[df["group"] == "B"]

pA_tut = (groupA["tutorial_complete"] == 1).mean()
pB_tut = (groupB["tutorial_complete"] == 1).mean()

pA_d7 = (groupA["retention_d7"] == 1).mean()
pB_d7 = (groupB["retention_d7"] == 1).mean()

revA = groupA["revenue"].mean()
revB = groupB["revenue"].mean()

metrics = ["Tutorial Completion", "D7 Retention", "Avg Revenue"]
A_values = [pA_tut, pA_d7, revA]
B_values = [pB_tut, pB_d7, revB]

x = np.arange(len(metrics))
width = 0.35

plt.figure()
plt.bar(x - width/2, A_values, width, label="Group A")
plt.bar(x + width/2, B_values, width, label="Group B")
plt.xticks(x, metrics, rotation=15)
plt.ylabel("Value")
plt.title("A/B Test Results: Group A vs Group B")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "ab_test_comparison.png"), dpi=150)
plt.close()

print(f"Charts saved to folder: {output_dir}")

# ========= COHORT HEATMAP (D7) =========
import os
import matplotlib.pyplot as plt
import numpy as np

# Make sure output folder exists
output_dir = "figures"
os.makedirs(output_dir, exist_ok=True)

# 1) Create install_week (cohort)
df["install_week"] = df["install_date"].dt.isocalendar().week

# 2) Compute D7 retention per cohort (week)
cohort_d7 = df.groupby("install_week")["retention_d7"].mean().sort_index()

# 3) Prepare data for heatmap: one column (D7) × N cohorts
heatmap_data = np.array(cohort_d7.values).reshape(-1, 1)

plt.figure()
plt.imshow(heatmap_data, aspect="auto")
plt.yticks(ticks=range(len(cohort_d7.index)),
           labels=cohort_d7.index.astype(str))
plt.xticks([0], ["D7 retention"])
plt.xlabel("Retention metric")
plt.ylabel("Install week (cohort)")
plt.title("Cohort Retention Heatmap (D7)")
plt.colorbar(label="Retention rate")
plt.tight_layout()

plt.savefig(os.path.join(output_dir, "d7_retention_heatmap.png"), dpi=150)
plt.close()

print("Saved heatmap to figures/d7_retention_heatmap.png")
